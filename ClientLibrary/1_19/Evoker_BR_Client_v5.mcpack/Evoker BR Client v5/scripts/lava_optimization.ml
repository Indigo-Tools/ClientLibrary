public class OptimizarAgua: MonoBehavior{

	private function Lava(){
	
new Vertex lava;
new bool optimization;
	
	lava.GetArchive(is(not)<Vertex>);
	
lava.optmization = true;
}

	referencial void Update(){

if(get.game.chunks afford character.camera == !optimization){
	
Optimization.execute.blocks.alpha as new Vector3(lava.transform.vertex.position.x,lava.transform.vertex.position.y,	lava.transform.vertex.position.z);
													Delete(lava as game.get.script.Blocks if(camera != camera.get.character.see as front);
	}
 }

}