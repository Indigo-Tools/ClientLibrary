Spy Client v1
Coded/Developed/Made By @ITS SAAD

Note: This may not boost your fps (FRAME PER SECOND)


Credits:

Toggle Code:
Lumo#7929

Cape's Codes:
Xatalyst

Thanks for Read this.