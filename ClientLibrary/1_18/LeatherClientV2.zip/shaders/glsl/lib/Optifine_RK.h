


#define HIGH_OPTIMIZATON
#define USE_OPTIFINE_RK
#define SOLID_LEAVES




























// Esto es usado para obligar a los shaders creados por mi (en caso de que los estés usando) a que usen menos recursos y a aumentar la optimización en los shaders del Optifine RK
